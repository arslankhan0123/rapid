@extends('layouts.app')
@section('title')
    {{ __('messages.balance_sheets.balance_sheet') }}
@endsection
@section('page_css')
    <link href="{{ asset('assets/css/jquery.dataTables.min.css') }}" rel="stylesheet" type="text/css" />
    <style>
        .balance-sheet-table {
            width: 100%;
        }

        .balance-sheet-table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }

        .balance-sheet-table .total-row {
            font-weight: bold;
            background-color: #e9ecef;
        }

        .balance-sheet-table .account-type-header {
            background-color: #d1ecf1;
            font-weight: bold;
        }

        .amount-column {
            text-align: right;
        }

        .balance-sheet-table tr.header-row {
            background-color: #d1ecf1;
            font-weight: bold;
        }

        .balance-sheet-table tr.subtotal-row {
            background-color: #e9ecef;
            font-weight: bold;
            border-top: 2px solid #dee2e6;
        }
    </style>
@endsection
@section('content')
    <section class="section">
        <div class="section-header">
            <h1>{{ __('messages.balance_sheets.balance_sheet') }}</h1>
            <div class="section-header-breadcrumb">
                <div class="card-header-action mr-3">
                    {{-- Optional: Add filter buttons here --}}
                </div>
            </div>
        </div>
        <div class="section-body">
            <div class="card">
                <div class="card-header">
                    <h4>{{ __('messages.balance_sheets.balance_sheet_report') }}</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped balance-sheet-table" id="balanceSheetTable">
                            <thead>
                                <tr>
                                    <th width="60%">{{ __('messages.balance_sheets.name_type') }}</th>
                                    <th width="20%" class="amount-column">{{ __('messages.balance_sheets.assets') }}</th>
                                    <th width="20%" class="amount-column">
                                        {{ __('messages.balance_sheets.liabilities_equity') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {{-- Data will be loaded via DataTables --}}
                            </tbody>
                            <tfoot>
                                <tr class="total-row">
                                    <td><strong>{{ __('messages.balance_sheets.total') }}</strong></td>
                                    <td class="amount-column"><strong id="total-assets">0.00</strong></td>
                                    <td class="amount-column"><strong id="total-liabilities">0.00</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@section('page_scripts')
    <script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ mix('assets/js/custom/custom-datatable.js') }}"></script>
@endsection

@section('scripts')
    <script>
        'use strict';

        let balanceSheetTable = $('#balanceSheetTable').DataTable({
            oLanguage: {
                'sEmptyTable': Lang.get('messages.common.no_data_available_in_table'),
                'sInfo': Lang.get('messages.common.data_base_entries'),
                sLengthMenu: Lang.get('messages.common.menu_entry'),
                sInfoEmpty: Lang.get('messages.common.no_entry'),
                sInfoFiltered: Lang.get('messages.common.filter_by'),
                sZeroRecords: Lang.get('messages.common.no_matching'),
            },
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('balance-sheets.index') }}",
                beforeSend: function() {
                    startLoader();
                },
                complete: function() {
                    stopLoader();
                }
            },
            columns: [{
                    data: 'name_type',
                    name: 'name_type',
                    orderable: false,
                    searchable: false
                },
                {
                    data: 'assets_amount',
                    name: 'assets_amount',
                    orderable: false,
                    searchable: false,
                    className: 'amount-column'
                },
                {
                    data: 'liabilities_amount',
                    name: 'liabilities_amount',
                    orderable: false,
                    searchable: false,
                    className: 'amount-column'
                }
            ],
            ordering: false,
            searching: false,
            paging: false,
            info: false,
            drawCallback: function(settings) {
                // Calculate totals
                let assetsTotal = 0;
                let liabilitiesTotal = 0;

                this.api().rows().every(function() {
                    const assetsAmount = parseFloat(this.data().assets_amount) || 0;
                    const liabilitiesAmount = parseFloat(this.data().liabilities_amount) || 0;

                    assetsTotal += assetsAmount;
                    liabilitiesTotal += liabilitiesAmount;
                });

                // Update footer totals
                $('#total-assets').text(assetsTotal.toFixed(2));
                $('#total-liabilities').text(liabilitiesTotal.toFixed(2));
            }
        });

        // Refresh button functionality (if needed)
        $(document).on('click', '#refreshBalanceSheet', function() {
            balanceSheetTable.ajax.reload();
        });
    </script>
@endsection
