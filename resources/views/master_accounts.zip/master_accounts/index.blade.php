@extends('layouts.app')
@section('title')
    {{ __('messages.master_accounts.master_accounts') }}
@endsection
@section('page_css')
    <link href="{{ asset('assets/css/jquery.dataTables.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
@endsection
@section('content')
    <section class="section">
        <div class="section-header item-align-right">
            <h1>{{ __('messages.master_accounts.master_accounts') }}</h1>
            <div class="section-header-breadcrumb float-right">
                <div class="card-header-action mr-3 select2-mobile-margin">
                </div>
            </div>
            @can('create_master_accounts')
                <div class="float-right">
                    <a href="{{ route('master-accounts.create') }}" class="btn btn-primary form-btn">
                        {{ __('messages.master_accounts.add') }}
                    </a>
                </div>
            @endcan
        </div>
        <div class="section-body">
            <div class="card">
                <div class="card-body">
                    @if (session()->has('flash_notification'))
                        @foreach (session('flash_notification') as $message)
                            <div class="alert alert-{{ $message['level'] }}">
                                {{ $message['message'] }}
                            </div>
                        @endforeach
                    @endif
                    @include('master_accounts.table')
                </div>
            </div>
        </div>
    </section>
@endsection
@section('page_scripts')
    <script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ mix('assets/js/custom/custom-datatable.js') }}"></script>
    <script src="{{ mix('assets/js/select2.min.js') }}"></script>
@endsection
@section('scripts')
    <script>
        'use strict';

        let tbl = $('#masterAccountTable').DataTable({
            oLanguage: {
                'sEmptyTable': Lang.get('messages.common.no_data_available_in_table'),
                'sInfo': Lang.get('messages.common.data_base_entries'),
                sLengthMenu: Lang.get('messages.common.menu_entry'),
                sInfoEmpty: Lang.get('messages.common.no_entry'),
                sInfoFiltered: Lang.get('messages.common.filter_by'),
                sZeroRecords: Lang.get('messages.common.no_matching'),
            },
            processing: true,
            serverSide: true,
            ajax: {
                url: route('master-accounts.index'),
                beforeSend: function() {
                    startLoader();
                },
                complete: function() {
                    stopLoader();
                }
            },
            lengthMenu: [
                [100, 300, 500, 999, -1],
                [100, 300, 500, 999, "All"]
            ],
            pageLength: 100,
            columns: [{
                    data: 'name',
                    name: 'name',
                    width: '15%'
                },
                {
                    data: function(row) {
                        return row.account_level;
                    },
                    name: 'account_level',
                    width: '15%'
                },
                {
                    data: function(row) {
                        return row.account_type;
                    },
                    name: 'account_type',
                    width: '15%'
                },
                {
                    data: function(row) {
                        return row.status ? "<span class='text-success text-center d-block'>Active</span>" :
                            "<span class='text-danger text-center d-block'>Inactive</span>";
                    },
                    name: 'status',
                    width: '10%'
                },
                {
                    data: function(row) {
                        return renderActionButtons(row.id);
                    },
                    name: 'id',
                    width: '10%'
                }
            ],
            responsive: true
        });

        $(document).on('click', '.edit-btn', function(event) {
            let did = $(event.currentTarget).data('id');
            const url = route('master-accounts.edit', did);
            window.location.href = url;
        });

        $(document).on('click', '.delete-btn', function(event) {
            let masterAccountId = $(event.currentTarget).data('id');
            deleteItem(route('master-accounts.destroy', masterAccountId), '#masterAccountTable',
                '{{ __('messages.master_accounts.master_account') }}');
        });

        $(document).on('click', '.view-btn', function(event) {
            let did = $(event.currentTarget).data('id');
            const url = route('master-accounts.show', did);
            window.location.href = url;
        });
    </script>
    <script>
        var messages = {
            delete: "{{ __('messages.common.delete') }}",
            edit: "{{ __('messages.common.edit') }}",
            view: "{{ __('messages.common.view') }}"
        };
        var permissions = {
            updateItem: "{{ auth()->user()->can('update_master_accounts') ? 'true' : 'false' }}",
            deleteItem: "{{ auth()->user()->can('delete_master_accounts') ? 'true' : 'false' }}",
            viewItem: "{{ auth()->user()->can('view_master_accounts') ? 'true' : 'false' }}"
        };

        function renderActionButtons(id) {
            let buttons = '';
            if (permissions.updateItem === 'true') {
                let editUrl = `{{ route('master-accounts.edit', ':id') }}`;
                editUrl = editUrl.replace(':id', id);
                buttons += `
                <a title="${messages.edit}" href="${editUrl}" class="btn btn-warning action-btn has-icon edit-btn" style="float:right;margin:2px;">
                    <i class="fa fa-edit"></i>
                </a>
            `;
            }
            if (permissions.viewItem === 'true') {
                let viewUrl = `{{ route('master-accounts.show', ':id') }}`;
                viewUrl = viewUrl.replace(':id', id);
                buttons += `
                <a title="${messages.view}" href="${viewUrl}" class="btn btn-info action-btn has-icon view-btn" style="float:right;margin:2px;">
                    <i class="fa fa-eye"></i>
                </a>
            `;
            }

            if (permissions.deleteItem === 'true') {
                buttons += `
                <a title="${messages.delete}" href="#" class="btn btn-danger action-btn has-icon delete-btn" data-id="${id}" style="float:right;margin:2px;">
                    <i class="fa fa-trash"></i>
                </a>
            `;
            }
            return buttons;
        }
    </script>
@endsection
